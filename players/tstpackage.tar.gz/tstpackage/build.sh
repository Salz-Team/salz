echo "build successfully called" > done.txt
