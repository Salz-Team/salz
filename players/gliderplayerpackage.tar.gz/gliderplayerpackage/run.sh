stack runghc ./gliderplayer.hs
