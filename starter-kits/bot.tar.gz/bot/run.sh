cd $(pwd)
runghc ./gliderplayer.hs
